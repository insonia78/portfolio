import { Albums } from './components/Albums';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
      </header>
      <Albums />
    </div>
  );
}

export default App;
