$(function() {
	$(".drawer-item").drawer({
		slideSpeed: 200,
		arrowIcon: "&#9660;"
	});
});