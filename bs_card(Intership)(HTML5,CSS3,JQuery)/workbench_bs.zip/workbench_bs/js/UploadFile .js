

function UploadFile()
{
	
	var fileLink = document.getElementById("link").getAttribute("href");
    alert(fileLink);	
	
	
	

}
document.onload = UploadFile();
document.onclick = UploadFile();