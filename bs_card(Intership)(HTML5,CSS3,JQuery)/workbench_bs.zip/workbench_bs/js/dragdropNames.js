$(document).ready(function(event) {
 var i = 0;
 
 var id = document.getElementsByTagName("text");
 
 for( i = 0; i < id.length;i++)
 {
     alert(id[0].getAttribute("class"));
 
  } 
 
 /*
 $(".innerLine").mouseenter(function(event,id){
   
     
	 var get = document.getElementById("textarea").onmouseover(this).getAttribute("class");
	    document.write(get);  
	      
		  
          		  
		  
	   
       
	   
         $("."+ get).toggleClass("addBorder")
      
	 $( id ).click(function(event){
	      
		 $( id ).toggleClass("addBorder")
		  $( id ).draggable({
		   
             containment :"parent"
		});
    });
  });
  $(id).mouseleave(function(){
         $(id ).toggleClass("addBorder")
   });
   /*   
	$( ".companyMessage" ).click(function(event){
	      $( ".companyMessage" ).draggable({
		   
             containment :"parent"
		});
    });
	$( ".fullName" ).click(function(event){
	      $( ".fullName" ).draggable({
		   
             containment :"parent"
		});
    });
	$( ".jobTitle" ).click(function(event){
	      $( ".jobTitle" ).draggable({
		   
             containment :"parent"
		});
    });
	$( ".address1" ).click(function(event){
	      $( ".address1" ).draggable({
		   
             containment :"parent"
		});
    });
	$( ".address2" ).click(function(event){
	      $( ".address2" ).draggable({
		   
             containment :"parent"
		});
    });
	$( ".phone" ).click(function(event){
	      $( ".phone" ).draggable({
		   
             containment :"parent"
		});
    });
	$( ".email" ).click(function(event){
	      $( ".email" ).draggable({
		   
             containment :"parent"
		});
    });
*/

});