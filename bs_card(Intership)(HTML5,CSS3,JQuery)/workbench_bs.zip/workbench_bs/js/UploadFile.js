$document

	
	
	


window.onclick = alert("hello"); 
 {
    
    document.getElementsByTagName("div").onclick = function()
    {
	   alert("heelo");   
	  // var fileLink = document.getElementsByTagName(tagname).getElementById("link").getAttribute("href");
       //alert(fileLink);	
	
    }
}
