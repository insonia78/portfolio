$(document).ready(function() {
 alert("hello");
$( ".innerLine" ).click(function() {
      
	 $( "#textarea" ).draggable({
		   
             containment :"parent"
		});
    });

});