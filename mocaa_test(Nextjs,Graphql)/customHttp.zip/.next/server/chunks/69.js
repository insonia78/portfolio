exports.id = 69;
exports.ids = [69];
exports.modules = {

/***/ 311:
/***/ ((module) => {

// Exports
module.exports = {
	"results_and_filter_container": "ResultsAndFilters_results_and_filter_container__q_oK_",
	"filters": "ResultsAndFilters_filters__i82Mp",
	"filters_container": "ResultsAndFilters_filters_container__t2wNo",
	"age": "ResultsAndFilters_age__EtGH_",
	"results": "ResultsAndFilters_results__KxIBQ",
	"select_container": "ResultsAndFilters_select_container__E4YK8"
};


/***/ }),

/***/ 69:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages_ResultsAndFilters)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@material-ui/core/Table"
var Table_ = __webpack_require__(880);
var Table_default = /*#__PURE__*/__webpack_require__.n(Table_);
// EXTERNAL MODULE: external "@material-ui/core/styles"
var styles_ = __webpack_require__(308);
// EXTERNAL MODULE: external "@material-ui/core/TableBody"
var TableBody_ = __webpack_require__(555);
var TableBody_default = /*#__PURE__*/__webpack_require__.n(TableBody_);
// EXTERNAL MODULE: external "@material-ui/core/TableCell"
var TableCell_ = __webpack_require__(740);
var TableCell_default = /*#__PURE__*/__webpack_require__.n(TableCell_);
// EXTERNAL MODULE: external "@material-ui/core/TableContainer"
var TableContainer_ = __webpack_require__(137);
var TableContainer_default = /*#__PURE__*/__webpack_require__.n(TableContainer_);
// EXTERNAL MODULE: external "@material-ui/core/TableHead"
var TableHead_ = __webpack_require__(956);
var TableHead_default = /*#__PURE__*/__webpack_require__.n(TableHead_);
// EXTERNAL MODULE: external "@material-ui/core/TableRow"
var TableRow_ = __webpack_require__(236);
var TableRow_default = /*#__PURE__*/__webpack_require__.n(TableRow_);
// EXTERNAL MODULE: external "@material-ui/core/Paper"
var Paper_ = __webpack_require__(640);
var Paper_default = /*#__PURE__*/__webpack_require__.n(Paper_);
// EXTERNAL MODULE: ./pages/ResultsAndFilters/css/ResultsAndFilters.module.css
var ResultsAndFilters_module = __webpack_require__(311);
var ResultsAndFilters_module_default = /*#__PURE__*/__webpack_require__.n(ResultsAndFilters_module);
// EXTERNAL MODULE: external "@apollo/client"
var client_ = __webpack_require__(114);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(689);
;// CONCATENATED MODULE: ./components/graphqlRequest/ResultsAndFilters/index.tsx

const SORT_EMPLOYEES_BY = client_.gql`
mutation sortEmployeeBy($sort:String,$to:String,$from:String,$name:String)
{
    sortEmployeeBy(sort:$sort,to:$to,from:$from,name:$name)
   {
       code
       message
       {
            first_name
            middle_name
            last_name
            age
            email
            id
            start_date
            title
       }
   }
}
`;
const FILTER_EMPLOYEES_BY_AGE = client_.gql`
mutation filterEmployeeByAge($to:String,$from:String,$sort:String,$name:String)
{
    filterEmployeeByAge(to:$to,from:$from,sort:$sort,name:$name)
   {
       code
       message
       {
            first_name
            middle_name
            last_name
            age
            email
            id
            start_date
            title
       }
   }
}
`;
/* harmony default export */ const ResultsAndFilters = ({
    FILTER_EMPLOYEES_BY_AGE,
    SORT_EMPLOYEES_BY
});

;// CONCATENATED MODULE: ./components/functions/ResultsAndFilters/index.tsx
const sortEmployees = (event, setDefaultSortValue, setSortValue, setSortBy, sortEmploeesBy, searchInputValue, defaultToValue, defaultFromValue, sortValue)=>{
    if (event.target.value === sortValue) return;
    setDefaultSortValue(event.target.value);
    setSortValue(event.target.value);
    setSortBy(event.target.value);
    sortEmploeesBy({
        variables: {
            name: searchInputValue,
            sort: event.target.value,
            to: defaultToValue === "pick_age" ? "" : defaultToValue,
            from: defaultFromValue === "pick_age" ? "" : defaultFromValue
        }
    });
};
const resetSelect = (setDefaultToValue, setDefaultFromValue)=>{
    setDefaultToValue("pick_age");
    setDefaultFromValue("pick_age");
};
const resetComponents = (setDefaultToValue, setDefaultFromValue, setDefaultSortValue)=>{
    resetSelect(setDefaultToValue, setDefaultFromValue);
    setDefaultSortValue("choose_sort");
};
const setToAge = (sortToValue, setDefaultToValue)=>{
    if (isNaN(sortToValue)) {
        alert("is not a value");
        return;
    }
    setDefaultToValue(sortToValue);
};
const setFromAge = (setDefaultFromValue, setAgeFilter, _filterEmployeeByAge, searchInputValue, fromValue, defaultToValue, defaultFromValue, sortValue)=>{
    if (isNaN(parseInt(fromValue))) {
        return;
    }
    if (isNaN(parseInt(defaultToValue))) {
        alert("please select To");
        return;
    }
    setDefaultFromValue(fromValue);
    if (parseInt(fromValue) < parseInt(defaultToValue)) {
        alert("wrong range");
        return;
    }
    setAgeFilter({
        to: defaultToValue,
        from: defaultFromValue
    });
    _filterEmployeeByAge({
        variables: {
            name: searchInputValue,
            to: defaultToValue,
            from: fromValue,
            sort: sortValue
        }
    });
};
/* harmony default export */ const functions_ResultsAndFilters = ({
    setFromAge,
    setToAge,
    resetComponents,
    resetSelect,
    sortEmployees
});

;// CONCATENATED MODULE: ./pages/ResultsAndFilters/index.tsx














const useStyles = (0,styles_.makeStyles)({
    table: {
        minWidth: "auto"
    }
});
const ResultsAndFilters_ResultsAndFilters = ({ resetPage , setResetPage , data =[] , setSearchByName , setAgeFilter , setSortBy , searchInputValue  })=>{
    const { 0: defaultToValue , 1: setDefaultToValue  } = (0,external_react_.useState)("");
    const { 0: defaultFromValue , 1: setDefaultFromValue  } = (0,external_react_.useState)("");
    const { 0: sortValue , 1: setSortValue  } = (0,external_react_.useState)("choose_sort");
    const { 0: defaultSortValue , 1: setDefaultSortValue  } = (0,external_react_.useState)("choose_sort");
    const classes = useStyles();
    let p = "pick_age";
    let ageTo = [];
    ageTo.push(/*#__PURE__*/ jsx_runtime_.jsx("option", {
        value: "pick_age",
        children: "Pick Age"
    }, "a" + 0));
    for(let i = 1; i <= 100; i++){
        ageTo.push(/*#__PURE__*/ jsx_runtime_.jsx("option", {
            value: i,
            children: i
        }, "a" + i));
    }
    const [_filterEmployeeByAge] = (0,client_.useMutation)(ResultsAndFilters.FILTER_EMPLOYEES_BY_AGE, {
        onError (err) {
            console.log(err);
            alert(err);
        },
        update (proxy, result) {
            console.log(result);
            if (result.data.filterEmployeeByAge.code !== 200) {
                alert(result.data.filterEmployeeByAge.message);
                return;
            }
            setSearchByName(result.data.filterEmployeeByAge.message);
        }
    });
    const [sortEmploeesBy] = (0,client_.useMutation)(ResultsAndFilters.SORT_EMPLOYEES_BY, {
        onError (err) {
            console.log(err);
            alert(err);
        },
        update (proxy, result) {
            console.log(result);
            if (result.data.sortEmployeeBy.code !== 200) {
                alert(result.data.sortEmployeeBy.message);
                return;
            }
            setSearchByName(result.data.sortEmployeeBy.message);
        }
    });
    (0,external_react_.useEffect)(()=>{
        if (resetPage) {
            functions_ResultsAndFilters.resetComponents(setDefaultToValue, setDefaultFromValue, setDefaultSortValue);
            setResetPage(false);
        }
    });
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (ResultsAndFilters_module_default()).results_and_filter_container,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (ResultsAndFilters_module_default()).filters,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (ResultsAndFilters_module_default()).filters_container,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            children: "FILTERS"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("fieldset", {
                            className: (ResultsAndFilters_module_default()).age,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("legend", {
                                    children: "AGE"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                    children: "To:"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("select", {
                                    value: defaultToValue,
                                    onFocus: ()=>functions_ResultsAndFilters.resetSelect(setDefaultToValue, setDefaultFromValue),
                                    onChange: (e)=>functions_ResultsAndFilters.setToAge(e.target.value, setDefaultToValue),
                                    children: ageTo
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                    children: "From:"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("select", {
                                    onChange: (e)=>{
                                        console.log(e.target.value);
                                        functions_ResultsAndFilters.setFromAge(setDefaultFromValue, setAgeFilter, _filterEmployeeByAge, searchInputValue, e.target.value, defaultToValue, defaultFromValue, sortValue);
                                    },
                                    value: defaultFromValue,
                                    children: ageTo
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (ResultsAndFilters_module_default()).results,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (ResultsAndFilters_module_default()).select_container,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                children: "Sort By:   "
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("select", {
                                value: defaultSortValue,
                                onChange: (e)=>functions_ResultsAndFilters.sortEmployees(e, setDefaultSortValue, setSortValue, setSortBy, sortEmploeesBy, searchInputValue, defaultToValue, defaultFromValue, sortValue),
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                        value: "choose_sort",
                                        children: "Choose Sort"
                                    }, "1aa"),
                                    /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                        value: "first_name",
                                        children: "First Name"
                                    }, "1a"),
                                    /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                        value: "last_name",
                                        children: "Last Name"
                                    }, "1b"),
                                    /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                        value: "age",
                                        children: "Age"
                                    }, "1c"),
                                    /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                        value: "email",
                                        children: "Email"
                                    }, "1d"),
                                    /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                        value: "title",
                                        children: "Title"
                                    }, "1e"),
                                    /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                        value: "start_date",
                                        children: "Start Date"
                                    }, "1f")
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((TableContainer_default()), {
                        component: (Paper_default()),
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Table_default()), {
                            className: classes.table,
                            size: "small",
                            "aria-label": "a dense table",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((TableHead_default()), {
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                children: "Id"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                align: "right",
                                                children: "First Name"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                align: "right",
                                                children: "Middle Name"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                align: "right",
                                                children: "Last Name"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                align: "right",
                                                children: "Age"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                align: "right",
                                                children: "Email"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                align: "right",
                                                children: "Title"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                align: "right",
                                                children: "Start Date"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((TableBody_default()), {
                                    children: data.map((row, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                    component: "th",
                                                    scope: "row",
                                                    children: row.id
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                    scope: "row",
                                                    children: row.first_name
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                    align: "right",
                                                    children: row.middle_name
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                    align: "right",
                                                    children: row.last_name
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                    align: "right",
                                                    children: row.age
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                    align: "right",
                                                    children: row.email
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                    align: "right",
                                                    children: row.title
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                    align: "right",
                                                    children: row.start_date
                                                })
                                            ]
                                        }, index))
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const pages_ResultsAndFilters = (ResultsAndFilters_ResultsAndFilters);


/***/ })

};
;