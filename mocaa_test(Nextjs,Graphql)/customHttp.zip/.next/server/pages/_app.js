"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 462:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "schema": () => (/* binding */ schema)
});

// NAMESPACE OBJECT: ./components/AllTypes/index.ts
var AllTypes_namespaceObject = {};
__webpack_require__.r(AllTypes_namespaceObject);
__webpack_require__.d(AllTypes_namespaceObject, {
  "default": () => (AllTypes)
});

;// CONCATENATED MODULE: external "@nexus/schema"
const schema_namespaceObject = require("@nexus/schema");
;// CONCATENATED MODULE: external "path"
const external_path_namespaceObject = require("path");
var external_path_default = /*#__PURE__*/__webpack_require__.n(external_path_namespaceObject);
;// CONCATENATED MODULE: ./components/AllTypes/Employee.ts

const Employee = (0,schema_namespaceObject.objectType)({
    name: "Employee",
    definition (t) {
        t.string("first_name");
        t.string("middle_name");
        t.string("last_name");
        t.string("age");
        t.string("email");
        t.string("title");
        t.string("id");
        t.string("start_date");
    }
});
/* harmony default export */ const AllTypes_Employee = (Employee);

;// CONCATENATED MODULE: ./components/AllTypes/Payload.ts


const Payload = (0,schema_namespaceObject.objectType)({
    name: "Payload",
    definition (t) {
        t.int("code");
        t.list.field("message", {
            type: AllTypes_Employee,
            resolve (payload) {
                return payload.message;
            }
        });
    }
});
/* harmony default export */ const AllTypes_Payload = (Payload);

;// CONCATENATED MODULE: ./components/data.ts
const data = {
    employees: [
        {
            first_name: "Thomas",
            middle_name: "",
            last_name: "Aurthur",
            age: "25",
            email: "test@test.com",
            id: "1",
            title: "Software Engineer",
            start_date: "12-01-2020"
        },
        {
            first_name: "Erik",
            middle_name: "",
            last_name: "BeatBeat",
            age: "40",
            email: "erik1@test.com",
            id: "2",
            title: "Accountated",
            start_date: "12-05-2018"
        },
        {
            first_name: "Susan",
            middle_name: "Osiris",
            last_name: "Zumba",
            age: "19",
            email: "susan90@test.com",
            id: "3",
            title: "Post Man",
            start_date: "09-05-2016"
        },
        {
            first_name: "Antony",
            middle_name: "",
            last_name: "JamJem",
            age: "34",
            email: "antony12@test.com",
            id: "4",
            title: "Analyst",
            start_date: "01-10-2016"
        },
        {
            first_name: "Anthony",
            middle_name: "",
            last_name: "MiauMiau",
            age: "34",
            email: "antonyMiauMiau@test.com",
            id: "5",
            title: "CFO",
            start_date: "03-10-2016"
        },
        {
            first_name: "Anthony",
            middle_name: "",
            last_name: "MiauMiau",
            age: "34",
            email: "antonyMiauMiau@test.com",
            id: "6",
            title: "CEO",
            start_date: "03-10-2016"
        },
        {
            first_name: "Thomas",
            middle_name: "",
            last_name: "Aurthurity",
            age: "25",
            email: "test1@test.com",
            id: "7",
            title: "Disk Washer",
            start_date: "11-01-2020"
        },
        {
            first_name: "Erikson",
            middle_name: "",
            last_name: "BeatGeat",
            age: "40",
            email: "erik12@test.com",
            id: "8",
            title: "Senior Manager",
            start_date: "12-01-2018"
        },
        {
            first_name: "Susany",
            middle_name: "Osirisined",
            last_name: "Zumbany",
            age: "121",
            email: "susan70@test.com",
            id: "9",
            title: "Full Stack Developer",
            start_date: "09-05-2016"
        },
        {
            first_name: "Antony",
            middle_name: "",
            last_name: "JamJemier",
            age: "39",
            email: "antony12@test.com",
            id: "10",
            title: "Senior Software Engineer",
            start_date: "01-10-2016"
        },
        {
            first_name: "Anthony",
            middle_name: "",
            last_name: "BeMiauMiau",
            age: "34",
            email: "antonyMiauMiau@test.com",
            id: "11",
            title: "Q/A Tester",
            start_date: "03-10-2016"
        },
        {
            first_name: "Anthony",
            middle_name: "",
            last_name: "GiauMiau",
            age: "54",
            email: "antonyMiauMiau@test.com",
            id: "12",
            title: "Clerk",
            start_date: "05-10-2016"
        }, 
    ]
};

;// CONCATENATED MODULE: ./components/AllTypes/Mutation.ts



const Sort = (sort, array)=>{
    let ar = [];
    if (sort.localeCompare("first_name") === 0) {
        array.sort((a, b)=>a.first_name.localeCompare(b.first_name));
    } else if (sort.localeCompare("last_name") === 0) {
        array.sort((a, b)=>a.last_name.localeCompare(b.last_name));
    } else if (sort.localeCompare("age") === 0) {
        array.sort((a, b)=>parseInt(a.age) - parseInt(b.age));
    } else if (sort.localeCompare("email") === 0) {
        array.sort((a, b)=>a.email.localeCompare(b.email));
    } else if (sort.localeCompare("title") === 0) {
        array.sort((a, b)=>a.title.localeCompare(b.title));
    } else if (sort.localeCompare("start_date") === 0) {
        array.sort((a, b)=>b.start_date.split("-").reverse().join("").localeCompare(a.start_date.split("-").reverse().join("")));
    } else {
        array.sort((a, b)=>parseInt(a.id) - parseInt(b.id));
    }
    return {
        code: 200,
        message: array
    };
};
const FilterByAge = (to, from, array)=>{
    let ar = [];
    array.sort((a, b)=>parseInt(a.age) - parseInt(b.age));
    to = parseInt(to);
    from = parseInt(from);
    return {
        code: 200,
        message: array.filter((element)=>element.age >= to && element.age <= from)
    };
};
const SearchEmployer = (name, data)=>{
    let ar = [];
    try {
        let lenght_of_the_name_to_search = name.trim().length;
        let it_matches = true;
        data.forEach((value)=>{
            let first_name = value.first_name.toLowerCase();
            let last_name = value.last_name.toLowerCase();
            let v = `${value.first_name} , ${value.middle_name !== "" ? value.middle_name + "," : ""} ${value.last_name}, ${value.title}, ${value.age}`;
            if (v.localeCompare(name) === 0) {
                ar.push(value);
                return {
                    code: 200,
                    message: ar
                };
            }
            if (first_name.localeCompare(name.toLowerCase()) === 0 && value.first_name.length === name.length) {
                ar.push(value);
            }
            if (last_name.localeCompare(name.toLowerCase()) === 0 && value.last_name.length === name.length) {
                ar.push(value);
            }
            for(let i = 0; i < lenght_of_the_name_to_search && (value.first_name.length > name.length || value.first_name.length < name.length); i++){
                if (first_name[i] !== name.toLowerCase()[i]) {
                    it_matches = false;
                    break;
                }
                if (first_name[i] === name.toLowerCase()[i]) {
                    it_matches = true;
                }
            }
            if (it_matches && (value.first_name.length > name.length || value.first_name.length < name.length)) {
                ar.push(value);
            }
            it_matches = true;
            for(let i1 = 0; i1 < lenght_of_the_name_to_search && (value.last_name.length > name.length || value.last_name.length < name.length); i1++){
                if (last_name[i1] !== name.toLowerCase()[i1]) {
                    it_matches = false;
                    break;
                }
                if (last_name[i1] === name.toLowerCase()[i1]) {
                    it_matches = true;
                }
            }
            if (it_matches && (value.last_name.length > name.length || value.last_name.length < name.length)) {
                ar.push(value);
            }
        });
    } catch (e) {
        console.log(e);
        return {
            code: 500,
            message: e
        };
    }
    return {
        code: 200,
        message: ar
    };
};
const Mutation = (0,schema_namespaceObject.extendType)({
    type: "Mutation",
    definition (t) {
        t.field("filterEmployeeByAge", {
            type: AllTypes_Payload,
            args: {
                to: (0,schema_namespaceObject.stringArg)(),
                from: (0,schema_namespaceObject.stringArg)(),
                sort: (0,schema_namespaceObject.stringArg)(),
                name: (0,schema_namespaceObject.stringArg)()
            },
            resolve: (root, args, ctx)=>{
                let _data = FilterByAge(args.to, args.from, data.employees);
                if (args.sort.localeCompare("choose_sort") === 0 && args.name.localeCompare("") === 0) return _data;
                if (!(args.name.localeCompare("") === 0)) _data = SearchEmployer(args.name, _data.message);
                return Sort(args.sort, _data.message);
            }
        }), t.field("sortEmployeeBy", {
            type: AllTypes_Payload,
            args: {
                sort: (0,schema_namespaceObject.stringArg)(),
                to: (0,schema_namespaceObject.stringArg)(),
                from: (0,schema_namespaceObject.stringArg)(),
                name: (0,schema_namespaceObject.stringArg)()
            },
            resolve: (root, args, ctx)=>{
                let ar = [];
                let _data;
                if (isNaN(parseInt(args.to)) && args.name.localeCompare("") === 0) return Sort(args.sort, data.employees);
                if (!(args.name.localeCompare("") === 0)) _data = SearchEmployer(args.name, data.employees);
                if (!isNaN(parseInt(args.to))) _data = FilterByAge(args.to, args.from, _data ? _data.message : data.employees);
                return Sort(args.sort, _data ? _data.message : data.employees);
            }
        }), t.field("getAllEmployees", {
            type: AllTypes_Payload,
            resolve: ()=>Sort("", data.employees)
        }), t.field("searchEmployer", {
            type: AllTypes_Payload,
            args: {
                name: (0,schema_namespaceObject.stringArg)(),
                to: (0,schema_namespaceObject.stringArg)(),
                from: (0,schema_namespaceObject.stringArg)(),
                sort: (0,schema_namespaceObject.stringArg)()
            },
            resolve: (root, args, ctx)=>{
                let response;
                if (!isNaN(parseInt(args.to))) {
                    response = FilterByAge(args.to, args.from, data.employees);
                    response = Sort(args.sort, response.message);
                    return SearchEmployer(args.name, response.message);
                }
                response = Sort(args.sort, data.employees);
                return SearchEmployer(args.name, response.message);
            }
        });
    }
});
/* harmony default export */ const AllTypes_Mutation = (Mutation);

;// CONCATENATED MODULE: ./components/AllTypes/index.ts



/* harmony default export */ const AllTypes = ({
    Mutation: AllTypes_Mutation,
    Payload: AllTypes_Payload,
    Employee: AllTypes_Employee
});

;// CONCATENATED MODULE: ./components/schema.ts



// const Query = queryType({
//     definition(t){
//         t.string("name");
//     }
// });
// const types = { Query };
const schema = (0,schema_namespaceObject.makeSchema)({
    types: AllTypes_namespaceObject,
    outputs: {
        schema: external_path_default().join(process.cwd(), "schema.graphql")
    },
    typegenAutoConfig: {
        sources: [
            {
                alias: "faces",
                source: external_path_default().join(process.cwd(), "interfaces"),
                typeMatch: (type)=>new RegExp(`(${type}Interface)`)
            }, 
        ],
        debug: "production" === "development"
    }
});


/***/ }),

/***/ 2:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@apollo/client"
var client_ = __webpack_require__(114);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(689);
;// CONCATENATED MODULE: ./components/apolloClient.ts


let apolloClient;
function createIsomorphicLink() {
    if (true) {
        // server
        const { SchemaLink  } = __webpack_require__(404);
        const { schema  } = __webpack_require__(462);
        return new SchemaLink({
            schema
        });
    } else {}
    return new client_.HttpLink({
        uri: "/api/graphql"
    });
}
function createApolloClient() {
    return new client_.ApolloClient({
        ssrMode: "undefined" === undefined,
        link: createIsomorphicLink(),
        cache: new client_.InMemoryCache()
    });
}
function initializeApollo(initialState = null) {
    const _apolloClient = apolloClient !== null && apolloClient !== void 0 ? apolloClient : createApolloClient();
    if (initialState) {
        _apolloClient.cache.restore(initialState);
    }
    if (false) {}
    apolloClient = apolloClient !== null && apolloClient !== void 0 ? apolloClient : _apolloClient;
    return apolloClient;
}
function useApollo(initialState) {
    const store = (0,external_react_.useMemo)(()=>initializeApollo(initialState), [
        initialState
    ]);
    return store;
}

;// CONCATENATED MODULE: ./pages/_app.tsx




function MyApp({ Component , pageProps  }) {
    const client = useApollo(pageProps.initialApolloState);
    return /*#__PURE__*/ jsx_runtime_.jsx(client_.ApolloProvider, {
        client: client,
        children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
            ...pageProps
        })
    });
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 114:
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ 404:
/***/ ((module) => {

module.exports = require("@apollo/client/link/schema");

/***/ }),

/***/ 689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(2));
module.exports = __webpack_exports__;

})();