export interface EmployeeInterface{
        first_name:String;
        middle_name:String;
        last_name:String;
        age:String;
        email:String;
        title:String;
        id:String;
        start_date:String;

}
