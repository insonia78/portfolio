import Mutation from "./Mutation";
import  Payload  from "./Payload";
import Employee from './Employee';

export default { Mutation, Payload,Employee } ;
