export const data = {
    employees: [
        {
           first_name:'Thomas',
           middle_name:'',
           last_name:'Aurthur',
           age:'25',
           email:'test@test.com',
           id:'1',
           title:'Software Engineer',
           start_date:'12-01-2020'

        },
        {
            first_name:'Erik',
            middle_name:'',
            last_name:'BeatBeat',
            age:'40',
            email:'erik1@test.com',
            id:'2',
            title:'Accountated',
            start_date:'12-05-2018'

        },
        {
            first_name:'Susan',
            middle_name:'Osiris',
            last_name:'Zumba',
            age:'19',
            email:'susan90@test.com',
            id:'3',
            title:'Post Man',
            start_date:'09-05-2016'

        },
        {
            first_name:'Antony',
            middle_name:'',
            last_name:'JamJem',
            age:'34',
            email:'antony12@test.com',
            id:'4',
            title:'Analyst',
            start_date:'01-10-2016'
        },
        {
            first_name:'Anthony',
            middle_name:'',
            last_name:'MiauMiau',
            age:'34',
            email:'antonyMiauMiau@test.com',
            id:'5',
            title:'CFO',
            start_date:'03-10-2016'

        },
        {
            first_name:'Anthony',
            middle_name:'',
            last_name:'MiauMiau',
            age:'34',
            email:'antonyMiauMiau@test.com',
            id:'6',
            title:'CEO',
            start_date:'03-10-2016'

        },
        {
            first_name:'Thomas',
            middle_name:'',
            last_name:'Aurthurity',
            age:'25',
            email:'test1@test.com',
            id:'7',
            title:'Disk Washer',
            start_date:'11-01-2020'
 
         },
         {
             first_name:'Erikson',
             middle_name:'',
             last_name:'BeatGeat',
             age:'40',
             email:'erik12@test.com',
             id:'8',
             title:'Senior Manager',
             start_date:'12-01-2018'
 
         },
         {
             first_name:'Susany',
             middle_name:'Osirisined',
             last_name:'Zumbany',
             age:'121',
             email:'susan70@test.com',
             id:'9',
             title:'Full Stack Developer',
             start_date:'09-05-2016'
 
         },
         {
             first_name:'Antony',
             middle_name:'',
             last_name:'JamJemier',
             age:'39',
             email:'antony12@test.com',
             id:'10',
             title:'Senior Software Engineer',
             start_date:'01-10-2016'
         },
         {
             first_name:'Anthony',
             middle_name:'',
             last_name:'BeMiauMiau',
             age:'34',
             email:'antonyMiauMiau@test.com',
             id:'11',
             title:'Q/A Tester',
             start_date:'03-10-2016'
 
         },
         {
             first_name:'Anthony',
             middle_name:'',
             last_name:'GiauMiau',
             age:'54',
             email:'antonyMiauMiau@test.com',
             id:'12',
             title:'Clerk',
             start_date:'05-10-2016'
 
         },
    ]

}