
export const getName = ():string=>{

       return "Esther";
}